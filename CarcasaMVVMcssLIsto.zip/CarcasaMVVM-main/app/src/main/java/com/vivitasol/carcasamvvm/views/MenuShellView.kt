package com.vivitasol.carcasamvvm.views

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.vivitasol.carcasamvvm.navigation.Route
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuShellView() {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val innerNavController = rememberNavController()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    text = "Menú",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(16.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Principal") },
                    selected = currentInnerRoute(innerNavController) == Route.Option1.route,
                    onClick = {
                        innerNavController.navigate(Route.Option1.route) {
                            popUpTo(Route.Option1.route) { inclusive = true }
                            launchSingleTop = true
                        }
                        scope.launch { drawerState.close() }
                    }
                )
                NavigationDrawerItem(
                    label = { Text("Puntos de Reciclaje") },
                    selected = currentInnerRoute(innerNavController) == Route.Map.route,
                    onClick = {
                        innerNavController.navigate(Route.Map.route) {
                            popUpTo(Route.Option1.route) { inclusive = false }
                            launchSingleTop = true
                        }
                        scope.launch { drawerState.close() }
                    }
                )
                NavigationDrawerItem(
                    label = { Text("Galería") },
                    selected = currentInnerRoute(innerNavController) == Route.Gallery.route,
                    onClick = {
                        innerNavController.navigate(Route.Gallery.route) {
                            popUpTo(Route.Option1.route) { inclusive = false }
                            launchSingleTop = true
                        }
                        scope.launch { drawerState.close() }
                    }
                )
                NavigationDrawerItem(
                    label = { Text("Soporte") },
                    selected = currentInnerRoute(innerNavController) == Route.Support.route,
                    onClick = {
                        innerNavController.navigate(Route.Support.route) {
                            popUpTo(Route.Option1.route) { inclusive = false }
                            launchSingleTop = true
                        }
                        scope.launch { drawerState.close() }
                    }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Reciclaje_Feliz") },
                    navigationIcon = {
                        IconButton(onClick = {
                            scope.launch {
                                if (drawerState.isClosed) drawerState.open() else drawerState.close()
                            }
                        }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menú")
                        }
                    }
                )
            }
        ) { innerPadding ->
            NavHost(
                navController = innerNavController,
                startDestination = Route.Option1.route,
                modifier = Modifier.padding(innerPadding)
            ) {
                composable(Route.Option1.route) { Option1View(navController = innerNavController) }
                
                // --- EL MAPA HA SIDO REACTIVADO ---
                composable(Route.Map.route) { MapView() }
                // --- FIN DEL CAMBIO ---
                
                composable(Route.Gallery.route) { GalleryView() }
                composable(Route.LocationsList.route) {
                    LocationsListView(onBack = { innerNavController.navigateUp() })
                }
                composable(Route.Support.route) { SupportView() }
            }
        }
    }
}

@Composable
private fun currentInnerRoute(navController: NavHostController): String? {
    val entry by navController.currentBackStackEntryAsState()
    return entry?.destination?.route
}
