package com.vivitasol.carcasamvvm.views

import androidx.compose.runtime.Composable
import androidx.navigation.NavController

/**
 * Este archivo es obsoleto. Su funcionalidad fue reemplazada por SupportView.kt.
 * El contenido ha sido vaciado para prevenir errores de compilación.
 */
@Composable
fun Option2View(navController: NavController) {
    // El contenido de esta vista ha sido eliminado porque ya no se utiliza.
}

@Composable
fun Option2DetailView(id: String, onBack: () -> Unit) {
    // El contenido de esta vista ha sido eliminado porque ya no se utiliza.
}
