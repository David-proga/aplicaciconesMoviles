package com.vivitasol.carcasamvvm.views

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vivitasol.carcasamvvm.viewmodels.Location
import com.vivitasol.carcasamvvm.viewmodels.LocationsListViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationsListView(
    onBack: () -> Unit,
    vm: LocationsListViewModel = viewModel()
) {
    val locations by vm.locations.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Puntos de Reciclaje") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(locations) { location ->
                LocationItem(location)
            }
        }
    }
}

@Composable
private fun LocationItem(location: Location) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(location.address, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text(location.city, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
