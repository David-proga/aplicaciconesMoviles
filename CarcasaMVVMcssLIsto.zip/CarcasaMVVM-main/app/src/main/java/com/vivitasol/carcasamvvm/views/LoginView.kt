package com.vivitasol.carcasamvvm.views

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.vivitasol.carcasamvvm.R
import com.vivitasol.carcasamvvm.viewmodels.LoginViewModel

@Composable
fun LoginView(navController: NavController, vm: LoginViewModel = viewModel()) {
    val email by vm.email.collectAsState()
    val password by vm.password.collectAsState()
    val emailError by vm.emailError.collectAsState()
    val passwordError by vm.passwordError.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(painter = painterResource(id = R.drawable.reciclaje), contentDescription = "Logo", modifier = Modifier.size(120.dp))
        Spacer(modifier = Modifier.height(16.dp))

        Text("Reciclaje_Feliz", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(32.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { vm.onEmailChange(it) },
            label = { Text("Email") },
            isError = emailError != null,
            singleLine = true
        )
        if (emailError != null) {
            Text(emailError!!, color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { vm.onPasswordChange(it) },
            label = { Text("Password") },
            isError = passwordError != null,
            singleLine = true,
            visualTransformation = PasswordVisualTransformation()
        )
        if (passwordError != null) {
            Text(passwordError!!, color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { vm.login(navController) },
            enabled = emailError == null && passwordError == null && email.isNotEmpty() && password.isNotEmpty()
        ) {
            Text("Login")
        }
    }
}
