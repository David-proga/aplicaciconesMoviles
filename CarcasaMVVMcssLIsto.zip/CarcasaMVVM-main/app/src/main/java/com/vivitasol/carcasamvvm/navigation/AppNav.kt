package com.vivitasol.carcasamvvm.navigation

sealed class Route(val route: String) {
    data object Login : Route("login")
    data object Welcome : Route("welcome")
    data object MenuShell : Route("menu_shell") // contenedor con drawer
    data object Option1 : Route("option1")
    // Option2 y Option2Detail han sido eliminadas y reemplazadas por Support

    data object Option3 : Route("option3")
    data object Option4 : Route("option4")
    data object Option5 : Route("option5")
    data object Map : Route("map")
    data object Gallery : Route("gallery")
    data object LocationsList : Route("locations_list")
    data object Support : Route("support") // Nueva ruta para Soporte
}
