package com.vivitasol.carcasamvvm.viewmodels

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class SupportViewModel : ViewModel() {

    private val _comment = MutableStateFlow("")
    val comment = _comment.asStateFlow()

    fun onCommentChange(text: String) {
        _comment.value = text
    }

    fun submitComment() {
        // Aquí iría la lógica para enviar el comentario a un backend o guardarlo.
        // Por ahora, simplemente lo limpiaremos.
        if (_comment.value.isNotBlank()) {
            println("Comentario enviado: ${_comment.value}")
            _comment.value = ""
        }
    }
}
