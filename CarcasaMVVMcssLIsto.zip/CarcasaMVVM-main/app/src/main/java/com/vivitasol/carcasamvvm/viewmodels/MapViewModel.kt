package com.vivitasol.carcasamvvm.viewmodels

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.osmdroid.util.GeoPoint // Importar GeoPoint de osmdroid

// Actualizar la clase de datos para que use GeoPoint
data class RecyclingPoint(val name: String, val location: GeoPoint)

class MapViewModel : ViewModel() {

    private val _recyclingPoints = MutableStateFlow<List<RecyclingPoint>>(
        listOf(
            // Actualizar la instanciación para que use GeoPoint
            RecyclingPoint("Punto Limpio 1", GeoPoint(-33.45694, -70.64827)),
            RecyclingPoint("Punto Limpio 2", GeoPoint(-33.4400, -70.6500)),
            RecyclingPoint("Punto Limpio 3", GeoPoint(-33.4600, -70.6600))
        )
    )
    val recyclingPoints = _recyclingPoints.asStateFlow()
}
