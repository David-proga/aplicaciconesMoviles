package com.vivitasol.carcasamvvm.viewmodels

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

data class Location(val address: String, val city: String)

class LocationsListViewModel : ViewModel() {
    private val _locations = MutableStateFlow<List<Location>>(
        listOf(
            Location("Av. Vicuña Mackenna 491", "Santiago"),
            Location("Moneda 1345", "Santiago Centro"),
            Location("Providencia 1208", "Providencia"),
            Location("Apoquindo 3400", "Las Condes"),
            Location("Bellavista 0121", "Recoleta")
        )
    )
    val locations = _locations.asStateFlow()
}
