package com.vivitasol.carcasamvvm.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavController
import com.vivitasol.carcasamvvm.navigation.Route
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class LoginViewModel : ViewModel() {

    private val _email = MutableStateFlow("")
    val email = _email.asStateFlow()

    private val _password = MutableStateFlow("")
    val password = _password.asStateFlow()

    private val _emailError = MutableStateFlow<String?>(null)
    val emailError = _emailError.asStateFlow()

    private val _passwordError = MutableStateFlow<String?>(null)
    val passwordError = _passwordError.asStateFlow()

    fun onEmailChange(email: String) {
        _email.value = email
        _emailError.value = if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            "Invalid email format"
        } else {
            null
        }
    }

    fun onPasswordChange(password: String) {
        _password.value = password
        _passwordError.value = if (password.length < 6) {
            "Password must be at least 6 characters"
        } else {
            null
        }
    }

    fun login(navController: NavController) {
        if (_emailError.value == null && _passwordError.value == null) {
            // For now, just navigate to the main screen
            navController.navigate(Route.MenuShell.route) {
                popUpTo(Route.Login.route) { inclusive = true }
            }
        }
    }
}
